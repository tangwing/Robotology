class Point
{
public:
	Point(){};
	Point(double x, double y, double z):dx(x),dy(y),dz(z){}
	double dx;
	double dy;
	double dz;
};